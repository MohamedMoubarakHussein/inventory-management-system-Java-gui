package controller;

import model.*;
import java.io.*;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminMethod {

    Methods method = new Methods();
    Connection connection = null;

    public AdminMethod() {
        //
    }

    public void add(Admin admin) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            PreparedStatement add = connection.prepareStatement("insert into SIGNUP values(?,?,?)");

            add.setString(1, admin.getName());
            add.setString(2, admin.getID());
            add.setString(3, admin.getPassword());

            int row = add.executeUpdate();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void edit(Admin admin, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String UpdateQuery = "Update SIGNUP set NAME='" + admin.getName() + "'" + ",ADID='" + admin.getID() + "'" + "where PASSWORD =" + Integer.valueOf(admin.getPassword());
            Statement Add = connection.createStatement();
            Add.executeUpdate(UpdateQuery);
            method.ShowDataInTable(table);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Admin admin, javax.swing.JTable table) {

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String ID = admin.getID();
            String Query = "Delete from SIGNUP where ADID=" + "'" + ID + "'";
            Statement Add = connection.createStatement();
            Add.executeUpdate(Query);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
