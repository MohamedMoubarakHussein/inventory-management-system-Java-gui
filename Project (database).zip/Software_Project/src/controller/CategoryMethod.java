package controller;

import model.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;

public class CategoryMethod {

    Methods method = new Methods();
    Connection connection = null;

    public CategoryMethod() {
        //
    }

    public void add(Category Category, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            PreparedStatement add = connection.prepareStatement("insert into CATEGORYTBL values(?,?)");

            add.setString(1, Category.getID());
            add.setString(2, Category.getName());
            int row = add.executeUpdate();
            connection.close();
            method.ShowDataInTable(table);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void edit(Category Category, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String UpdateQuery = "Update CATEGORYTBL set CATNAME='" + Category.getName() + "'" + "where CATID =" + Category.getID();
            Statement Add = connection.createStatement();
            Add.executeUpdate(UpdateQuery);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Category Category, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String Id = Category.getID();
            String Query = "Delete from CATEGORYTBL where CatID= " + Id;
            Statement Add = connection.createStatement();
            Add.executeUpdate(Query);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
