package controller;

import model.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;

public class CustomerMethod {

    Methods method = new Methods();
    Connection connection = null;

    public CustomerMethod() {
        //
    }

    public void add(Customer customer, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            PreparedStatement add = connection.prepareStatement("insert into CUSTOMERTBL values(?,?,?)");

            add.setString(1, customer.getID());
            add.setString(2, customer.getName());
            add.setString(3, customer.getPhone());

            int row = add.executeUpdate();
            connection.close();
            method.ShowDataInTable(table);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void edit(Customer customer, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String UpdateQuery = "Update CUSTOMERTBL set CUSTNAME='" + customer.getName() + "'" + ",CUSTPHONE='" + customer.getPhone() + "'" + "where CUSTID =" + customer.getID();
            Statement Add = connection.createStatement();
            Add.executeUpdate(UpdateQuery);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Customer customer, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String Id = customer.getID();
            String Query = "Delete from CUSTOMERTBL where CUSTID= " + Id;
            Statement Add = connection.createStatement();
            Add.executeUpdate(Query);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
