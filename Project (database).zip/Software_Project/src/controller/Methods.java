package controller;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class Methods {

    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;

    public Methods() {
        //
    }

    public static void delete(javax.swing.JTable table) {
        
    }

    public void ShowDataInTable(javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            statement = connection.createStatement();
            resultSet = statement.executeQuery("Select * from SIGNUP");
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
