package controller;

import model.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ProductMethod {

    Methods method = new Methods();
    Connection connection = null;

    public ProductMethod() {
        
    }

    public void add(Product product, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            PreparedStatement add = connection.prepareStatement("insert into PRODUCTTBL values(?,?,?,?,?)");
            add.setString(1, product.getID());
            add.setString(2, product.getName());
            add.setString(3, product.getDescription());
            add.setString(4, product.getQuantity());
            add.setString(5, product.getCategory().getSelectedItem().toString());

            int row = add.executeUpdate();
            connection.close();
            method.ShowDataInTable(table);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void edit(Product product, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String UpdateQuery = "Update PRODUCTTBL set PRODNAME='" + product.getName() + "'" + ",PRODQTY=" + product.getQuantity() + "" + ",PRODDESC='" + product.getDescription() + "'" + ",CATCB='" + product.getCategory().getSelectedItem().toString() + "'" + "where PRODID =" + product.getID();
            Statement Add = connection.createStatement();
            Add.executeUpdate(UpdateQuery);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Product product, javax.swing.JTable table) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/User1?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            String Id = product.getID();
            String Query = "Delete from PRODUCTTBL where PRODID= " + Id;
            Statement Add = connection.createStatement();
            Add.executeUpdate(Query);
            method.ShowDataInTable(table);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
