package model;

import controller.*;

public class Category {
    
    private String id;
    private String name;
    private CategoryMethod category = new CategoryMethod();
    
    public Category() {
        //
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getID() {
        return this.id;
    }
    
    public void add(javax.swing.JTable table) {
        category.add(this, table);
    }
    
    public void edit(javax.swing.JTable table) {
        category.edit(this, table);
    }
    
    public void delete(javax.swing.JTable table) {
        category.delete(this, table);
    }
    
}
