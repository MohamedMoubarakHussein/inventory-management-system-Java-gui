package model;

import controller.*;

public class Customer {
    
    private String id;
    private String name;
    private String phone;
    private CustomerMethod customer = new CustomerMethod();
    
    public Customer() {
        //
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getID() {
        return this.id;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return this.phone;
    }
    
    public void add(javax.swing.JTable table) {
        customer.add(this, table);
    }
    
    public void edit(javax.swing.JTable table) {
        customer.edit(this, table);
    }
    
    public void delete(javax.swing.JTable table) {
        customer.delete(this, table);
    }
    
}